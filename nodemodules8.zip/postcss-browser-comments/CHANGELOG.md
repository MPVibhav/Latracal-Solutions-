# Changes to PostCSS Browser Comments

### 4.0.0 (April 28, 2021)

- Updated: PostCSS 8 compatibility (major)

### 3.0.0 (May 24, 2019)

- Updated: Node 8+ compatibility (major)

### 2.0.0 (September 6, 2018)

- Update to PostCSS 7.0.2 (major)
- Update to browserslist 4.1.1 (major)

### 1.0.0 (June 15, 2018)

- Initial version
