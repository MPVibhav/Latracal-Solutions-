declare function ownKeys<T extends Record<PropertyKey, V>, V>(object: T): (keyof T)[];

export = ownKeys;
