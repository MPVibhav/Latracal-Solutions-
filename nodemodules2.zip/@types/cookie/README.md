# Installation
> `npm install --save @types/cookie`

# Summary
This package contains type definitions for cookie (https://github.com/jshttp/cookie).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/cookie.

### Additional Details
 * Last updated: Sun, 26 Nov 2023 22:07:01 GMT
 * Dependencies: none

# Credits
These definitions were written by [Pine Mizune](https://github.com/pine), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
