'use strict';

/** @type {import('./functionApply')} */
module.exports = Function.prototype.apply;
