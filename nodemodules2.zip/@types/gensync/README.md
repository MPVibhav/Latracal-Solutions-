# Installation
> `npm install --save @types/gensync`

# Summary
This package contains type definitions for gensync (https://github.com/loganfsmyth/gensync).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/gensync.

### Additional Details
 * Last updated: Wed, 22 Nov 2023 00:24:48 GMT
 * Dependencies: none

# Credits
These definitions were written by [Jake Bailey](https://github.com/jakebailey), and [Nicolò Ribaudo](https://github.com/nicolo-ribaudo).
